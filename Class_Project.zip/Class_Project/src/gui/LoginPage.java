package gui;

public class LoginPage {
	// login page fx
	
	

}
