package gui;

public class AccountPage {

}
