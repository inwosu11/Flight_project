package common;

public class VO {
	
	private Customer customer;

}
