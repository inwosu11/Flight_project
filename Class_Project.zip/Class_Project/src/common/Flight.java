package common;

public class Flight {

}
