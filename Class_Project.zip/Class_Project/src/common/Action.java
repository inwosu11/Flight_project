package common;

public class Action {

}
