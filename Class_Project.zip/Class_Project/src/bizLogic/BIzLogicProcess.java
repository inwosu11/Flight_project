package bizLogic;

public class BIzLogicProcess {

}
