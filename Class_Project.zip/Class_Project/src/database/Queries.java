package database;

public class Queries {

}
