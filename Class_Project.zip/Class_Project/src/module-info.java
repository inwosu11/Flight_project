/**
 * 
 */
/**
 * 
 */
module Class_Project {
	requires java.sql;
}